#!/bin/sh
echo ""
cd /
echo "Beginning install script."
exec > /log/update.log
exec 2>&1
echo "***********************************"
echo "***********************************"
echo "***********************************"
echo "UPDATE INITIATED $(date)"
echo ""
echo "Current Version:"
cat ${ROOT}/VERSION
echo ""
echo "***********************************"
echo ""
echo "Current python_stderr:"
head -n20 ${ROOT}/log/python_stderr.log
echo ""
echo "***********************************"
echo ""
echo "Current Firmware Directory:"
ls -lhR /firmware
rm /firmware/*.px4
tar -xzvf ${ROOT}/tmp/updates.tar.gz -C ${ROOT}/tmp/
echo ""
echo "***********************************"
echo ""
echo "This Update Directory:"
ls -lhR ${ROOT}/tmp/updates
echo ""
echo "***********************************"
echo ""
echo "Updating Golden Image:"
umount /dev/mmcblk0p1 &> /dev/null
mkfs.vfat /dev/mmcblk0p1 -n GOLDEN &> /dev/null
mkdir -p ${ROOT}/tmp/golden
mount /dev/mmcblk0p1 ${ROOT}/tmp/golden
tar -xzvf ${ROOT}/tmp/updates/solo_update.tar.gz -C ${ROOT}/tmp/golden
echo ""
echo "***********************************"
echo ""
echo "New Golden Image:"
echo ""
echo "***********************************"
echo ""
ls -lhR ${ROOT}/tmp/golden
umount ${ROOT}/tmp/golden
sololink_config --update-prepare sololink
mv ${ROOT}/tmp/updates/* ${ROOT}/log/updates
touch ${ROOT}/log/updates/UPDATE
echo ""
echo "***********************************"
echo ""
echo "System Update Directory:"
echo ""
echo "***********************************"
echo ""
ls -lhR ${ROOT}/log/updates/
echo ""
echo "***********************************"
echo ""
echo "Executing Sysem Update..."
sololink_config --update-apply sololink